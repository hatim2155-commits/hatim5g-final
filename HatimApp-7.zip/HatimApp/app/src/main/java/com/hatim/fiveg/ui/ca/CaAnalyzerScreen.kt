package com.hatim.fiveg.ui.ca

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hatim.fiveg.data.repository.RouterRepository
import com.hatim.fiveg.domain.router.AdapterResult
import com.hatim.fiveg.domain.router.model.CaInfo
import com.hatim.fiveg.domain.router.model.CarrierComponent

/**
 * §3 CA ANALYZER. Shows each active LTE/NR carrier component plus totals.
 * Per spec, this screen explicitly disclaims that total bandwidth != speed.
 */
@Composable
fun CaAnalyzerScreen(routerRepository: RouterRepository) {
    var caInfo by remember { mutableStateOf<CaInfo?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        val profileId = routerRepository.resolveDefaultProfileId()
        if (profileId == null) {
            message = "لا يوجد راوتر محفوظ. أضف راوترًا من صفحة الراوترات."
            return@LaunchedEffect
        }
        val resolved = routerRepository.resolveAdapter(profileId)
        if (resolved == null) {
            message = "لا يوجد راوتر افتراضي محدد."
            return@LaunchedEffect
        }
        val (adapter, config) = resolved
        when (val result = adapter.getCAInfo(config)) {
            is AdapterResult.Success -> caInfo = result.data
            is AdapterResult.Failure -> message = result.message ?: "تعذر قراءة بيانات CA"
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("CA ANALYZER", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))

        message?.let {
            Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Text(it, Modifier.padding(12.dp))
            }
        }

        val info = caInfo
        if (info != null) {
            Text("LTE", style = MaterialTheme.typography.titleLarge)
            ComponentList(info.lteComponents)

            Spacer(Modifier.height(12.dp))
            Text("5G", style = MaterialTheme.typography.titleLarge)
            ComponentList(info.nrComponents)

            Spacer(Modifier.height(16.dp))
            SummaryRow("LTE CA", info.lteCaLabel.orNull() ?: "غير متوفر")
            SummaryRow("NR CA", info.nrCaLabel.orNull() ?: "غير متوفر")
            SummaryRow(
                "Total LTE Bandwidth",
                info.totalLteBandwidthMhz.orNull()?.let { "$it MHz" } ?: "غير متوفر"
            )
            SummaryRow(
                "Total NR Bandwidth",
                info.totalNrBandwidthMhz.orNull()?.let { "$it MHz" } ?: "غير متوفر"
            )
            SummaryRow(
                "Total Aggregated Bandwidth",
                info.totalAggregatedBandwidthMhz.orNull()?.let { "$it MHz" } ?: "غير متوفر"
            )

            Spacer(Modifier.height(12.dp))
            Text(
                "ملاحظة: إجمالي عرض النطاق (Bandwidth) لا يساوي سرعة الإنترنت الفعلية مباشرة. " +
                    "السرعة الحقيقية تعتمد أيضًا على جودة الإشارة، الازدحام، والشبكة الأساسية للمشغل.",
                style = MaterialTheme.typography.labelSmall
            )
        } else if (message == null) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun ComponentList(components: List<CarrierComponent>) {
    if (components.isEmpty()) {
        Text("غير متوفر")
        return
    }
    LazyColumn(modifier = Modifier.heightIn(max = 160.dp)) {
        items(components) { c ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(c.band + if (c.isPrimary) " (Primary)" else "")
                Text("${c.bandwidthMhz} MHz")
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label)
        Text(value, fontWeight = FontWeight.Bold)
    }
}
