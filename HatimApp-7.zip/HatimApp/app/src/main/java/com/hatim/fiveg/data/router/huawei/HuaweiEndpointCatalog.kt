package com.hatim.fiveg.data.router.huawei

/**
 * Catalog of CANDIDATE read-only status endpoints found on Huawei
 * HiLink-style web admin interfaces across various models/firmwares.
 *
 * IMPORTANT: nothing in this list is assumed to exist on any given device.
 * Every entry is a "worth trying" candidate, standard read-only device
 * telemetry paths exposed by the router's own web UI (the same URLs the
 * browser itself calls when you view the status page) — never an
 * undocumented/private endpoint, never anything used to bypass auth.
 * HuaweiApiDiscoveryService probes them and reports which one(s) actually
 * respond with data on the connected device; nothing here is treated as
 * ground truth until confirmed by a real HTTP response.
 *
 * `H155_383` is called out explicitly since that's the confirmed device
 * `api/device/signal` was verified against — but discovery runs the same
 * way regardless of model, so unlisted/future Huawei models automatically
 * get a chance to match one of these candidates too.
 */
object HuaweiEndpointCatalog {

    enum class Category { SIGNAL, DEVICE_INFO, NETWORK_STATUS, PLMN }

    data class Candidate(val path: String, val category: Category, val note: String)

    /**
     * Confirmed on: Huawei H155-383.
     * Listed first so already-known-good devices skip straight to it.
     */
    const val CONFIRMED_SIGNAL_ENDPOINT = "api/device/signal"

    val candidates: List<Candidate> = listOf(
        Candidate(CONFIRMED_SIGNAL_ENDPOINT, Category.SIGNAL, "مؤكد على H155-383"),
        Candidate("api/device/information", Category.DEVICE_INFO, "شائع على أجهزة HiLink — غير مؤكد بعد"),
        Candidate("api/monitoring/status", Category.NETWORK_STATUS, "شائع على أجهزة HiLink — غير مؤكد بعد"),
        Candidate("api/net/current-plmn", Category.PLMN, "شائع على أجهزة HiLink — غير مؤكد بعد"),
        Candidate("api/monitoring/traffic-statistics", Category.NETWORK_STATUS, "غير مؤكد بعد")
    )

    fun candidatesFor(category: Category): List<Candidate> = candidates.filter { it.category == category }
}
