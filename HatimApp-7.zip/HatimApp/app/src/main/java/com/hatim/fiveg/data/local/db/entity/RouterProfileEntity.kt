package com.hatim.fiveg.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * Note: username/password are deliberately NOT stored here. Only the
 * non-sensitive profile metadata lives in Room; actual credentials live in
 * SecureCredentialsStore (EncryptedSharedPreferences / Keystore-backed),
 * keyed by [id].
 */
@Entity(tableName = "router_profiles")
data class RouterProfileEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val displayName: String,       // e.g. "راوتر المنزل"
    val manufacturerKey: String,   // e.g. "huawei"
    val routerIp: String,
    val isDefault: Boolean = false
)
