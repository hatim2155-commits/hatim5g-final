package com.hatim.fiveg.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** result: one of CONNECTED, FAILED, TIMEOUT, UNSUPPORTED, UNKNOWN (see spec §18). */
@Entity(tableName = "band_tests")
data class BandTestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: String,
    val timestampMillis: Long,
    val bandCombination: String, // e.g. "N78+B1+B3"
    val result: String
)
