package com.hatim.fiveg.ui.diagnostics

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hatim.fiveg.data.repository.RouterRepository

/**
 * §21 Diagnostics. Placeholder shell: real diagnosis text must be derived
 * from actual adapter data (see spec's ban on claiming tower congestion
 * without real evidence) — wiring this to live SignalInfo/CaInfo is the
 * next implementation step once an adapter is functional end-to-end.
 */
@Composable
fun DiagnosticsScreen(routerRepository: RouterRepository) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Diagnostics", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(12.dp))
        DiagnosticRow("الإشارة", "غير متوفر")
        DiagnosticRow("جودة 5G", "غير متوفر")
        DiagnosticRow("ازدحام الشبكة", "غير معروف")
        DiagnosticRow("CA", "غير متوفر")
        DiagnosticRow("LTE Anchor", "غير متوفر")
    }
}

@Composable
private fun DiagnosticRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label)
        Text(value)
    }
}
