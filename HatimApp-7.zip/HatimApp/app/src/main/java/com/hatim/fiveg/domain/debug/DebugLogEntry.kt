package com.hatim.fiveg.domain.debug

/**
 * One attempt to reach a candidate router API endpoint. Used to power the
 * in-app Debug screen so a network technician can see exactly which
 * endpoint worked, its HTTP status, and response time — with NOTHING
 * sensitive (no password, no full request body) ever stored here.
 */
data class DebugLogEntry(
    val id: Long,
    val timestampMillis: Long,
    val manufacturerKey: String,
    val endpointPath: String,
    val httpStatus: Int?,
    val responseTimeMs: Long,
    val outcome: DebugOutcome,
    val note: String? = null
)

enum class DebugOutcome { SUCCESS, HTTP_ERROR, UNRECOGNIZED_FORMAT, UNREACHABLE, TIMEOUT }
