package com.hatim.fiveg.ui.theme

import androidx.compose.ui.graphics.Color

// HATIM 5G brand palette — dark-mode first, network-monitor inspired.
val HatimBackground = Color(0xFF0B0F14)
val HatimSurface = Color(0xFF121821)
val HatimSurfaceVariant = Color(0xFF1B2430)
val HatimPrimary = Color(0xFF00E5C7)      // signature "5G" teal accent
val HatimSecondary = Color(0xFF3D8BFF)    // 4G / LTE accent
val HatimOnBackground = Color(0xFFE6EDF3)
val HatimOnSurfaceMuted = Color(0xFF8A97A6)

// Signal-quality status colors (thresholds live in Configuration, not here).
val StatusExcellent = Color(0xFF29D67A)
val StatusGood = Color(0xFF9BE05B)
val StatusFair = Color(0xFFF5C542)
val StatusPoor = Color(0xFFF25C54)
val StatusUnknown = Color(0xFF5B6472)
