package com.hatim.fiveg.data.local.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.hatim.fiveg.data.local.db.entity.SignalLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SignalLogDao {
    @Insert
    suspend fun insert(log: SignalLogEntity)

    @Query("SELECT * FROM signal_logs WHERE profileId = :profileId ORDER BY timestampMillis DESC LIMIT :limit")
    fun observeRecent(profileId: String, limit: Int = 500): Flow<List<SignalLogEntity>>

    @Query("SELECT * FROM signal_logs WHERE profileId = :profileId AND timestampMillis BETWEEN :from AND :to ORDER BY timestampMillis ASC")
    suspend fun getRange(profileId: String, from: Long, to: Long): List<SignalLogEntity>

    @Query("DELETE FROM signal_logs WHERE profileId = :profileId")
    suspend fun clearForProfile(profileId: String)
}
