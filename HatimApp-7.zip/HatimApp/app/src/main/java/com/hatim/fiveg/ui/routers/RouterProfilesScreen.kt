package com.hatim.fiveg.ui.routers

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.hatim.fiveg.data.local.db.entity.RouterProfileEntity
import com.hatim.fiveg.data.repository.RouterRepository
import com.hatim.fiveg.domain.router.Manufacturer
import com.hatim.fiveg.ui.common.rememberVm

/**
 * §5/§6/§8: Router Settings + manufacturer picker + multi-profile management,
 * all in one screen (the "Router Credentials Manager" opens as a dialog,
 * matching §28's "كلمة مرور الراوتر" entry point from Settings too).
 */
@Composable
fun RouterProfilesScreen(routerRepository: RouterRepository) {
    val viewModel = rememberVm { RouterProfilesViewModel(routerRepository) }
    val profiles by viewModel.profiles.collectAsState()
    var showEditor by remember { mutableStateOf(false) }
    var editingProfile by remember { mutableStateOf<RouterProfileEntity?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = {
                editingProfile = null
                showEditor = true
            }) { Icon(Icons.Default.Add, contentDescription = "إضافة راوتر") }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Text("الراوترات المحفوظة", style = MaterialTheme.typography.titleLarge) }

            items(profiles, key = { it.id }) { profile ->
                RouterProfileRow(
                    profile = profile,
                    onEdit = { editingProfile = profile; showEditor = true },
                    onDelete = { viewModel.deleteProfile(profile) },
                    onSetDefault = { viewModel.setDefault(profile) }
                )
            }

            if (profiles.isEmpty()) {
                item { Text("لا يوجد راوتر محفوظ بعد. اضغط + لإضافة راوتر.") }
            }
        }
    }

    if (showEditor) {
        // Pre-fill with whatever is actually stored for this profile — not
        // blank defaults — so editing (e.g. just to fix the IP) never wipes
        // a previously saved username/password. Read fresh on every open
        // since editingProfile can change between openings.
        val (initialUsername, initialPassword) = remember(editingProfile) {
            editingProfile?.let { viewModel.currentCredentials(it.id) } ?: ("admin" to "")
        }
        RouterEditorDialog(
            existing = editingProfile,
            initialUsername = initialUsername,
            initialPassword = initialPassword,
            onDismiss = { showEditor = false },
            onSave = { name, manufacturer, ip, username, password ->
                viewModel.addOrUpdateProfile(
                    existing = editingProfile,
                    displayName = name,
                    manufacturer = manufacturer,
                    routerIp = ip,
                    username = username,
                    password = password
                )
                showEditor = false
            }
        )
    }
}

@Composable
private fun RouterProfileRow(
    profile: RouterProfileEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onSetDefault: () -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(profile.displayName, style = MaterialTheme.typography.titleLarge)
                    Text("${Manufacturer.fromKey(profile.manufacturerKey).displayNameAr} — ${profile.routerIp}")
                }
                if (profile.isDefault) {
                    AssistChip(onClick = {}, enabled = false, label = { Text("افتراضي") })
                }
            }
            Row(modifier = Modifier.padding(top = 8.dp)) {
                TextButton(onClick = onEdit) { Text("تعديل") }
                TextButton(onClick = onSetDefault) { Text("تعيين كافتراضي") }
                TextButton(onClick = onDelete) { Text("حذف") }
            }
        }
    }
}

/** §6: choosing a manufacturer auto-fills the suggested default IP (editable). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RouterEditorDialog(
    existing: RouterProfileEntity?,
    initialUsername: String,
    initialPassword: String,
    onDismiss: () -> Unit,
    onSave: (name: String, manufacturer: Manufacturer, ip: String, username: String, password: String) -> Unit
) {
    var name by remember { mutableStateOf(existing?.displayName ?: "") }
    var manufacturer by remember {
        mutableStateOf(Manufacturer.fromKey(existing?.manufacturerKey ?: Manufacturer.UNKNOWN.key))
    }
    var ip by remember { mutableStateOf(existing?.routerIp ?: manufacturer.suggestedDefaultIp ?: "") }
    var username by remember { mutableStateOf(initialUsername) }
    var password by remember { mutableStateOf(initialPassword) }
    var manufacturerMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "إضافة راوتر" else "تعديل راوتر") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text("اسم الراوتر") }, modifier = Modifier.fillMaxWidth()
                )

                ExposedDropdownMenuBox(
                    expanded = manufacturerMenuExpanded,
                    onExpandedChange = { manufacturerMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        readOnly = true,
                        value = manufacturer.displayNameAr,
                        onValueChange = {},
                        label = { Text("الشركة المصنعة") },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = manufacturerMenuExpanded,
                        onDismissRequest = { manufacturerMenuExpanded = false }
                    ) {
                        Manufacturer.entries.filter { it != Manufacturer.UNKNOWN }.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option.displayNameAr) },
                                onClick = {
                                    manufacturer = option
                                    // Auto-fill suggested IP, but user can still edit it.
                                    option.suggestedDefaultIp?.let { ip = it }
                                    manufacturerMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = ip, onValueChange = { ip = it },
                    label = { Text("عنوان IP للراوتر") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = username, onValueChange = { username = it },
                    label = { Text("اسم المستخدم") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = password, onValueChange = { password = it },
                    label = { Text("كلمة المرور") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "لن يتم إرسال بيانات الدخول إلى أي خادم خارجي — تُستخدم فقط للاتصال المحلي بالراوتر.",
                    style = MaterialTheme.typography.labelSmall
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(name.ifBlank { manufacturer.displayNameAr }, manufacturer, ip, username, password)
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
