package com.hatim.fiveg.data.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores router usernames/passwords ONLY on-device, encrypted with a key
 * held in the Android Keystore. Nothing here ever touches the network.
 *
 * Per project security rules:
 *   - Router password / username / IMEI / any local router data must never
 *     be sent to an external server.
 *   - The app is "local network first": credentials are used solely to talk
 *     directly to the router's own IP on the LAN.
 */
class SecureCredentialsStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "hatim_router_credentials",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveCredentials(profileId: String, username: String, password: String) {
        prefs.edit()
            .putString(usernameKey(profileId), username)
            .putString(passwordKey(profileId), password)
            .apply()
    }

    fun getUsername(profileId: String): String? = prefs.getString(usernameKey(profileId), null)

    fun getPassword(profileId: String): String? = prefs.getString(passwordKey(profileId), null)

    fun clearCredentials(profileId: String) {
        prefs.edit()
            .remove(usernameKey(profileId))
            .remove(passwordKey(profileId))
            .apply()
    }

    /** Masked form for display, e.g. in a profile list — never the raw value. */
    fun maskedPassword(profileId: String): String {
        val stored = getPassword(profileId) ?: return ""
        return "•".repeat(stored.length.coerceIn(6, 12))
    }

    private fun usernameKey(profileId: String) = "username_$profileId"
    private fun passwordKey(profileId: String) = "password_$profileId"
}
