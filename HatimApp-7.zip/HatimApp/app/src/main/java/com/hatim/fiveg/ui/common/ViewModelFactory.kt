package com.hatim.fiveg.ui.common

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.Composable

/** Tiny factory so screens can build a ViewModel with constructor args without Hilt. */
class SimpleViewModelFactory<T : ViewModel>(private val creator: () -> T) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <U : ViewModel> create(modelClass: Class<U>): U = creator() as U
}

@Composable
inline fun <reified T : ViewModel> rememberVm(noinline creator: () -> T): T =
    viewModel(factory = SimpleViewModelFactory(creator))
