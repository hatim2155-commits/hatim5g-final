package com.hatim.fiveg.data.router.huawei

import com.hatim.fiveg.data.debug.DebugLogStore
import com.hatim.fiveg.domain.router.*
import com.hatim.fiveg.domain.router.model.*
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Adapter for Huawei HiLink-style home routers/CPEs.
 *
 * Confirmed device: Huawei H155-383 (api/device/signal verified against a
 * real response — see HuaweiSignalXmlParser). Other Huawei models/firmwares
 * are supported through [HuaweiApiDiscoveryService] instead of assuming
 * they share the same endpoint: on first read, the adapter probes the
 * candidates in [HuaweiEndpointCatalog] and remembers whichever one actually
 * worked for THIS router instance, rather than hardcoding one path for all
 * Huawei devices.
 *
 * Still unimplemented (would need their own confirmed XML dumps before
 * being wired up, per the "never invent an endpoint" rule):
 *   - RouterInfo / FirmwareInfo -> candidate: api/device/information
 *   - NetworkStatus             -> candidates: api/monitoring/status,
 *                                  api/net/current-plmn
 *   - login() with a real session/token handshake, only needed if a future
 *     endpoint turns out to require auth (api/device/signal did not).
 * These stay AdapterResult.Failure(UNSUPPORTED_MODEL) until a real
 * response for them is confirmed and added to HuaweiEndpointCatalog.
 */
class HuaweiAdapter(
    debugLogStore: DebugLogStore,
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()
) : RouterAdapter {

    override val manufacturerKey: String = "huawei"

    private val discovery = HuaweiApiDiscoveryService(httpClient, debugLogStore)

    /** Endpoint path that worked last time, keyed by router IP, so repeated
     *  reads skip straight to it instead of re-running full discovery. */
    private val knownSignalEndpointByIp = mutableMapOf<String, String>()

    private suspend fun fetchRawSignal(config: RouterConnectionConfig): AdapterResult<HuaweiRawSignal> {
        val cachedPath = knownSignalEndpointByIp[config.routerIp]
        if (cachedPath != null) {
            val result = discovery.fetchKnownSignalEndpoint(config, cachedPath)
            if (result is AdapterResult.Success) return result
            // Cached endpoint stopped working (firmware update, different
            // device on that IP, etc.) — fall through and re-discover.
            knownSignalEndpointByIp.remove(config.routerIp)
        }

        return when (val discovered = discovery.discoverSignalEndpoint(config)) {
            is AdapterResult.Success -> {
                knownSignalEndpointByIp[config.routerIp] = discovered.data.endpointPath
                AdapterResult.Success(discovered.data.raw)
            }
            is AdapterResult.Failure -> discovered
        }
    }

    override suspend fun login(config: RouterConnectionConfig): AdapterResult<Unit> {
        // No confirmed Huawei model in this project needs a separate login
        // handshake before api/device/signal responds. Treat a successful
        // discovery/read as the reachability + auth check for now.
        return when (fetchRawSignal(config)) {
            is AdapterResult.Success -> AdapterResult.Success(Unit)
            is AdapterResult.Failure -> AdapterResult.Failure(
                AdapterFailureReason.UNSUPPORTED_MODEL,
                "تعذر العثور على Endpoint معروف لهذا الجهاز حتى الآن"
            )
        }
    }

    override suspend fun getRouterInfo(config: RouterConnectionConfig): AdapterResult<RouterInfo> =
        AdapterResult.Failure(AdapterFailureReason.UNSUPPORTED_MODEL)

    override suspend fun getNetworkStatus(config: RouterConnectionConfig): AdapterResult<NetworkStatus> =
        AdapterResult.Failure(AdapterFailureReason.UNSUPPORTED_MODEL)

    override suspend fun getLTEInfo(config: RouterConnectionConfig): AdapterResult<LteInfo> =
        when (val result = fetchRawSignal(config)) {
            is AdapterResult.Success -> AdapterResult.Success(HuaweiSignalMapper.toLteInfo(result.data))
            is AdapterResult.Failure -> result
        }

    override suspend fun getNRInfo(config: RouterConnectionConfig): AdapterResult<NrInfo> =
        when (val result = fetchRawSignal(config)) {
            is AdapterResult.Success -> AdapterResult.Success(HuaweiSignalMapper.toNrInfo(result.data))
            is AdapterResult.Failure -> result
        }

    override suspend fun getCAInfo(config: RouterConnectionConfig): AdapterResult<CaInfo> =
        when (val result = fetchRawSignal(config)) {
            is AdapterResult.Success -> AdapterResult.Success(HuaweiSignalMapper.toCaInfo(result.data))
            is AdapterResult.Failure -> result
        }

    override suspend fun getSignalInfo(config: RouterConnectionConfig): AdapterResult<SignalInfo> =
        when (val result = fetchRawSignal(config)) {
            is AdapterResult.Success -> AdapterResult.Success(HuaweiSignalMapper.toSignalInfo(result.data))
            is AdapterResult.Failure -> result
        }

    override suspend fun getCellInfo(config: RouterConnectionConfig): AdapterResult<CellInfo> =
        when (val result = fetchRawSignal(config)) {
            is AdapterResult.Success -> AdapterResult.Success(HuaweiSignalMapper.toCellInfo(result.data))
            is AdapterResult.Failure -> result
        }

    override suspend fun getFirmwareInfo(config: RouterConnectionConfig): AdapterResult<FirmwareInfo> =
        AdapterResult.Failure(AdapterFailureReason.UNSUPPORTED_MODEL)

    override suspend fun supportsBandLock(config: RouterConnectionConfig): Boolean = false
}
