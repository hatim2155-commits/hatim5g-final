package com.hatim.fiveg.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hatim.fiveg.data.repository.RouterRepository
import com.hatim.fiveg.domain.SignalQualityConfig
import com.hatim.fiveg.ui.common.rememberVm
import com.hatim.fiveg.ui.components.MetricCard

/**
 * §2 Dashboard. Reads the default router profile and shows connection +
 * 4G/5G summary. Every value falls back to "غير متوفر" via MetricCard when
 * the adapter can't provide it — this screen never fabricates numbers.
 */
@Composable
fun DashboardScreen(routerRepository: RouterRepository) {
    val viewModel = rememberVm { DashboardViewModel(routerRepository) }
    val state by viewModel.uiState.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.refresh()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("HATIM", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
        Text("5G", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(16.dp))

        if (state.isLoading) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        state.statusMessage?.let {
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Text(it, modifier = Modifier.padding(12.dp))
            }
        }

        Text("حالة الاتصال", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))

        val status = state.networkStatus
        ConnectionSummaryCard(
            networkTypeLabel = status?.networkType?.name ?: "غير متوفر",
            operator = status?.operatorName?.orNull() ?: "غير متوفر",
            routerIp = status?.routerIp?.orNull() ?: "غير متوفر",
            pingMs = status?.pingMs?.orNull(),
            downloadMbps = status?.downloadMbps?.orNull(),
            uploadMbps = status?.uploadMbps?.orNull()
        )

        Spacer(Modifier.height(16.dp))
        Text("4G / LTE", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))

        val lte = state.lteInfo
        BandSummaryRow(
            bandLabel = lte?.band?.orNull(),
            bandwidthMhz = lte?.bandwidthMhz?.orNull(),
            pci = lte?.pci?.orNull(),
            carrierAggregation = lte?.carrierAggregation?.orNull()
        )
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.heightIn(max = 220.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                MetricCard("RSRP", lte?.rsrp?.orNull(), "dBm", SignalQualityConfig.rsrp(lte?.rsrp?.orNull()))
            }
            item {
                MetricCard("SINR", lte?.sinr?.orNull(), "dB", SignalQualityConfig.sinr(lte?.sinr?.orNull()))
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("5G / NR", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))

        val nr = state.nrInfo
        BandSummaryRow(
            bandLabel = nr?.band?.orNull(),
            bandwidthMhz = nr?.bandwidthMhz?.orNull(),
            pci = nr?.pci?.orNull(),
            carrierAggregation = nr?.carrierAggregation?.orNull()
        )
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.heightIn(max = 220.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                MetricCard("RSRP", nr?.rsrp?.orNull(), "dBm", SignalQualityConfig.rsrp(nr?.rsrp?.orNull()))
            }
            item {
                MetricCard("SINR", nr?.sinr?.orNull(), "dB", SignalQualityConfig.sinr(nr?.sinr?.orNull()))
            }
        }
    }
}

/** Shows which band the router is actually connected to — not just signal numbers. */
@Composable
private fun BandSummaryRow(
    bandLabel: String?,
    bandwidthMhz: Double?,
    pci: Int?,
    carrierAggregation: String?
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("التردد (Band)", style = MaterialTheme.typography.labelSmall)
                Text(bandLabel ?: "غير متوفر", fontWeight = FontWeight.Bold)
            }
            Column {
                Text("Bandwidth", style = MaterialTheme.typography.labelSmall)
                Text(bandwidthMhz?.let { "$it MHz" } ?: "غير متوفر")
            }
            Column {
                Text("PCI", style = MaterialTheme.typography.labelSmall)
                Text(pci?.toString() ?: "غير متوفر")
            }
            Column {
                Text("CA", style = MaterialTheme.typography.labelSmall)
                Text(carrierAggregation ?: "غير متوفر")
            }
        }
    }
}

@Composable
private fun ConnectionSummaryCard(
    networkTypeLabel: String,
    operator: String,
    routerIp: String,
    pingMs: Int?,
    downloadMbps: Double?,
    uploadMbps: Double?
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("نوع الشبكة")
                Text(networkTypeLabel, fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("المشغل")
                Text(operator)
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("IP الراوتر")
                Text(routerIp)
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Ping")
                Text(pingMs?.let { "$it ms" } ?: "غير متوفر")
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Download / Upload")
                Text(
                    "${downloadMbps?.let { "%.1f".format(it) } ?: "—"} / " +
                        (uploadMbps?.let { "%.1f".format(it) } ?: "—") + " Mbps"
                )
            }
        }
    }
}
