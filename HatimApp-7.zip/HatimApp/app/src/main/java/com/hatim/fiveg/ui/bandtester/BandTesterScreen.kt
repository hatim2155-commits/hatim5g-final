package com.hatim.fiveg.ui.bandtester

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hatim.fiveg.data.repository.RouterRepository

private val availableBands = listOf("N78", "N40", "N41", "N77", "N79", "B1", "B3", "B8", "B28", "B40", "B41")

/**
 * §18 Band Tester. Lets the user pick a combination and records a real
 * outcome (CONNECTED / FAILED / TIMEOUT / UNSUPPORTED / UNKNOWN) — never a
 * guess about support before an actual test or a documented capability
 * response from the router.
 */
@Composable
fun BandTesterScreen(routerRepository: RouterRepository) {
    val selected = remember { mutableStateListOf<String>() }
    var results by remember { mutableStateOf(listOf<Pair<String, String>>()) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Band Tester", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(12.dp))
        Text("اختر تركيبة الترددات للاختبار")

        FlowRowBands(selected)

        Spacer(Modifier.height(12.dp))
        Button(
            enabled = selected.isNotEmpty(),
            onClick = {
                val combo = selected.joinToString("+")
                // TODO: replace UNKNOWN with a real adapter-driven test once
                // a manufacturer exposes a documented band-lock/status API.
                results = results + (combo to "UNKNOWN")
            }
        ) { Text("اختبار") }

        Spacer(Modifier.height(16.dp))
        Text("النتائج", style = MaterialTheme.typography.titleLarge)
        LazyColumn {
            items(results) { (combo, result) ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(combo)
                    Text(result)
                }
            }
        }
    }
}

@Composable
private fun FlowRowBands(selected: MutableList<String>) {
    Column {
        availableBands.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { band ->
                    FilterChip(
                        selected = selected.contains(band),
                        onClick = {
                            if (selected.contains(band)) selected.remove(band) else selected.add(band)
                        },
                        label = { Text(band) }
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}
