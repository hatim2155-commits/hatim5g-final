package com.hatim.fiveg.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = HatimPrimary,
    secondary = HatimSecondary,
    background = HatimBackground,
    surface = HatimSurface,
    surfaceVariant = HatimSurfaceVariant,
    onBackground = HatimOnBackground,
    onSurface = HatimOnBackground
)

private val LightColors = lightColorScheme(
    primary = HatimPrimary,
    secondary = HatimSecondary
)

/**
 * HATIM 5G is dark-mode-first per spec. [useDarkTheme] is exposed so the
 * Settings screen can offer Dark / Light / System, but the default value
 * always resolves to dark unless the user (or system) says otherwise.
 */
@Composable
fun HatimTheme(
    useDarkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colors = if (useDarkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = HatimTypography,
        content = content
    )
}
