package com.hatim.fiveg.data.local.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.hatim.fiveg.data.local.db.entity.BandTestEntity
import com.hatim.fiveg.data.local.db.entity.SpeedTestEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SpeedTestDao {
    @Insert
    suspend fun insert(result: SpeedTestEntity)

    @Query("SELECT * FROM speed_tests WHERE profileId = :profileId ORDER BY timestampMillis DESC")
    fun observeAll(profileId: String): Flow<List<SpeedTestEntity>>
}

@Dao
interface BandTestDao {
    @Insert
    suspend fun insert(result: BandTestEntity)

    @Query("SELECT * FROM band_tests WHERE profileId = :profileId ORDER BY timestampMillis DESC")
    fun observeAll(profileId: String): Flow<List<BandTestEntity>>
}
