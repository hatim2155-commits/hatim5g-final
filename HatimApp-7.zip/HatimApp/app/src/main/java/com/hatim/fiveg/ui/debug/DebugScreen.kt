package com.hatim.fiveg.ui.debug

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hatim.fiveg.data.debug.DebugLogStore
import com.hatim.fiveg.domain.debug.DebugLogEntry
import com.hatim.fiveg.domain.debug.DebugOutcome
import com.hatim.fiveg.ui.theme.StatusExcellent
import com.hatim.fiveg.ui.theme.StatusFair
import com.hatim.fiveg.ui.theme.StatusPoor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Shows every Router API Discovery attempt: which candidate endpoint was
 * tried, HTTP status, response time, and outcome. Deliberately never shows
 * username/password or any request/response body — see DebugLogEntry.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DebugScreen(debugLogStore: DebugLogStore, onBack: () -> Unit) {
    val entries by debugLogStore.entries.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("وضع Debug") },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("رجوع") }
                },
                actions = {
                    TextButton(onClick = { debugLogStore.clear() }) { Text("مسح") }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(
                "سجل محاولات اكتشاف/قراءة API الخاص بالراوتر. لا تُعرض هنا أي بيانات دخول أو محتوى حساس.",
                style = MaterialTheme.typography.labelSmall
            )
            Spacer(Modifier.height(12.dp))

            if (entries.isEmpty()) {
                Text("لا توجد محاولات مسجّلة بعد. افتح الرئيسية أو CA Analyzer لبدء القراءة.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(entries, key = { it.id }) { entry ->
                        DebugEntryRow(entry)
                    }
                }
            }
        }
    }
}

@Composable
private fun DebugEntryRow(entry: DebugLogEntry) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(entry.endpointPath, fontWeight = FontWeight.Bold)
                Text(entry.manufacturerKey)
            }
            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OutcomeChip(entry.outcome)
                Text("HTTP ${entry.httpStatus ?: "—"}")
                Text("${entry.responseTimeMs} ms")
            }
            Spacer(Modifier.height(4.dp))
            Text(
                timeFormatter.format(Date(entry.timestampMillis)),
                style = MaterialTheme.typography.labelSmall
            )
            entry.note?.let {
                Text(it, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.US)

@Composable
private fun OutcomeChip(outcome: DebugOutcome) {
    val (label, color) = when (outcome) {
        DebugOutcome.SUCCESS -> "نجاح" to StatusExcellent
        DebugOutcome.HTTP_ERROR -> "خطأ HTTP" to StatusPoor
        DebugOutcome.UNRECOGNIZED_FORMAT -> "شكل غير معروف" to StatusFair
        DebugOutcome.UNREACHABLE -> "غير متاح" to StatusPoor
        DebugOutcome.TIMEOUT -> "انتهت المهلة" to StatusPoor
    }
    AssistChip(
        onClick = {},
        enabled = false,
        label = { Text(label) },
        colors = AssistChipDefaults.assistChipColors(
            disabledContainerColor = color.copy(alpha = 0.18f),
            disabledLabelColor = color
        )
    )
}
