package com.hatim.fiveg.domain.router

/**
 * Supported manufacturer keys. "OTHER"/"UNKNOWN" always falls back to a
 * generic adapter that reports UNSUPPORTED_MODEL rather than guessing.
 *
 * Default IPs are starting suggestions only — the spec explicitly forbids
 * assuming every device from a manufacturer shares one IP. The Router
 * Profile screen must always let the user override it.
 */
enum class Manufacturer(val key: String, val displayNameAr: String, val suggestedDefaultIp: String?) {
    HUAWEI("huawei", "Huawei", "192.168.8.1"),
    ZTE("zte", "ZTE", "192.168.0.1"),
    TP_LINK("tplink", "TP-Link", "192.168.0.1"),
    NOKIA("nokia", "Nokia", "192.168.18.1"),
    ZYXEL("zyxel", "Zyxel", "192.168.1.1"),
    DLINK("dlink", "D-Link", "192.168.0.1"),
    OTHER("other", "أخرى", null),
    UNKNOWN("unknown", "غير معروف", null);

    companion object {
        fun fromKey(key: String): Manufacturer = entries.firstOrNull { it.key == key } ?: UNKNOWN
    }
}
