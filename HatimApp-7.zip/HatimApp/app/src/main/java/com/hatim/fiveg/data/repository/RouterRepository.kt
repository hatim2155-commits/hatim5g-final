package com.hatim.fiveg.data.repository

import com.hatim.fiveg.data.local.db.AppDatabase
import com.hatim.fiveg.data.local.db.entity.RouterProfileEntity
import com.hatim.fiveg.data.router.RouterAdapterFactory
import com.hatim.fiveg.data.security.SecureCredentialsStore
import com.hatim.fiveg.domain.router.Manufacturer
import com.hatim.fiveg.domain.router.RouterAdapter
import com.hatim.fiveg.domain.router.RouterConnectionConfig
import kotlinx.coroutines.flow.Flow

/**
 * Single entry point the ViewModels use. It resolves a profile ->
 * (manufacturer, ip, credentials) -> the right RouterAdapter, then delegates.
 * ViewModels never talk to RouterAdapter or SecureCredentialsStore directly.
 */
class RouterRepository(
    private val database: AppDatabase,
    private val credentialsStore: SecureCredentialsStore,
    private val adapterFactory: RouterAdapterFactory
) {
    // Keeps the same RouterAdapter instance alive per profile so a Huawei
    // adapter's discovered endpoint (see HuaweiAdapter) survives across
    // repeated Dashboard/CA/Signal reads instead of re-discovering every time.
    private val adapterCache = mutableMapOf<String, RouterAdapter>()

    fun observeProfiles(): Flow<List<RouterProfileEntity>> =
        database.routerProfileDao().observeAll()

    suspend fun saveProfile(
        profile: RouterProfileEntity,
        username: String,
        password: String
    ) {
        database.routerProfileDao().upsert(profile)
        credentialsStore.saveCredentials(profile.id, username, password)
        // Manufacturer/IP may have changed — drop any cached adapter so the
        // next read re-resolves (and re-discovers) against the new config.
        adapterCache.remove(profile.id)
    }

    suspend fun deleteProfile(profile: RouterProfileEntity) {
        database.routerProfileDao().delete(profile)
        credentialsStore.clearCredentials(profile.id)
        adapterCache.remove(profile.id)
    }

    suspend fun setDefaultProfile(profileId: String) {
        database.routerProfileDao().clearDefaultFlag()
        database.routerProfileDao().setDefault(profileId)
    }

    /**
     * The actual id of the profile screens should read from by default: the
     * one the user marked as default, or — if none is marked — the first
     * saved profile. Null only when no profile has been saved at all.
     *
     * Screens must call this instead of guessing/hardcoding a profile id.
     */
    suspend fun resolveDefaultProfileId(): String? =
        database.routerProfileDao().getDefaultOrFirst()?.id

    /**
     * The credentials actually stored for a profile right now. The Router
     * Profiles edit dialog must call this to pre-fill its username/password
     * fields — without it, editing a profile silently overwrites real saved
     * credentials with the dialog's blank defaults ("admin" / "") the next
     * time the user hits Save, even if they didn't touch those fields.
     */
    fun currentCredentials(profileId: String): Pair<String, String> =
        (credentialsStore.getUsername(profileId) ?: "admin") to
            (credentialsStore.getPassword(profileId) ?: "")

    /** Resolves the live [RouterAdapter] + connection config for a profile. */
    suspend fun resolveAdapter(profileId: String): Pair<RouterAdapter, RouterConnectionConfig>? {
        val profile = database.routerProfileDao().getById(profileId) ?: return null
        val username = credentialsStore.getUsername(profileId) ?: "admin"
        val password = credentialsStore.getPassword(profileId) ?: ""
        val adapter = adapterCache.getOrPut(profileId) {
            adapterFactory.create(Manufacturer.fromKey(profile.manufacturerKey))
        }
        val config = RouterConnectionConfig(
            routerIp = profile.routerIp,
            username = username,
            password = password
        )
        return adapter to config
    }
}
