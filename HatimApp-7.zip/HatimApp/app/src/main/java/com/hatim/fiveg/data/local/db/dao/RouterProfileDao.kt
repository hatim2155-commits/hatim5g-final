package com.hatim.fiveg.data.local.db.dao

import androidx.room.*
import com.hatim.fiveg.data.local.db.entity.RouterProfileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RouterProfileDao {
    @Query("SELECT * FROM router_profiles ORDER BY isDefault DESC, displayName ASC")
    fun observeAll(): Flow<List<RouterProfileEntity>>

    @Query("SELECT * FROM router_profiles WHERE id = :id")
    suspend fun getById(id: String): RouterProfileEntity?

    @Query("SELECT * FROM router_profiles WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefault(): RouterProfileEntity?

    /**
     * The profile screens like Dashboard/CA Analyzer should actually read
     * from: the one marked default, or — if the user hasn't picked one yet —
     * simply the first saved profile, so the app never shows "no router
     * saved" when one clearly exists. isDefault DESC puts a default-flagged
     * row first if there is one.
     */
    @Query("SELECT * FROM router_profiles ORDER BY isDefault DESC, displayName ASC LIMIT 1")
    suspend fun getDefaultOrFirst(): RouterProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: RouterProfileEntity)

    @Delete
    suspend fun delete(profile: RouterProfileEntity)

    @Query("UPDATE router_profiles SET isDefault = 0")
    suspend fun clearDefaultFlag()

    @Query("UPDATE router_profiles SET isDefault = 1 WHERE id = :id")
    suspend fun setDefault(id: String)
}
