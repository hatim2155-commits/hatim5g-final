package com.hatim.fiveg.domain

/**
 * All "ممتاز/جيد/متوسط/ضعيف" thresholds live here so they can be tuned in
 * one place (spec §4 explicitly asks for this to be configurable).
 * TODO: expose this via a Settings sub-screen backed by DataStore once the
 * rest of the UI is wired up; for now it's a single editable object.
 */
enum class SignalQuality { EXCELLENT, GOOD, FAIR, POOR, UNKNOWN }

object SignalQualityConfig {

    fun rsrp(value: Int?): SignalQuality = when {
        value == null -> SignalQuality.UNKNOWN
        value >= -80 -> SignalQuality.EXCELLENT
        value >= -95 -> SignalQuality.GOOD
        value >= -105 -> SignalQuality.FAIR
        else -> SignalQuality.POOR
    }

    fun rsrq(value: Int?): SignalQuality = when {
        value == null -> SignalQuality.UNKNOWN
        value >= -10 -> SignalQuality.EXCELLENT
        value >= -15 -> SignalQuality.GOOD
        value >= -20 -> SignalQuality.FAIR
        else -> SignalQuality.POOR
    }

    fun sinr(value: Int?): SignalQuality = when {
        value == null -> SignalQuality.UNKNOWN
        value >= 20 -> SignalQuality.EXCELLENT
        value >= 13 -> SignalQuality.GOOD
        value >= 0 -> SignalQuality.FAIR
        else -> SignalQuality.POOR
    }

    fun rssi(value: Int?): SignalQuality = when {
        value == null -> SignalQuality.UNKNOWN
        value >= -65 -> SignalQuality.EXCELLENT
        value >= -75 -> SignalQuality.GOOD
        value >= -85 -> SignalQuality.FAIR
        else -> SignalQuality.POOR
    }

    fun cqi(value: Int?): SignalQuality = when {
        value == null -> SignalQuality.UNKNOWN
        value >= 12 -> SignalQuality.EXCELLENT
        value >= 8 -> SignalQuality.GOOD
        value >= 4 -> SignalQuality.FAIR
        else -> SignalQuality.POOR
    }

    fun labelAr(quality: SignalQuality): String = when (quality) {
        SignalQuality.EXCELLENT -> "ممتاز"
        SignalQuality.GOOD -> "جيد"
        SignalQuality.FAIR -> "متوسط"
        SignalQuality.POOR -> "ضعيف"
        SignalQuality.UNKNOWN -> "غير متوفر"
    }
}
