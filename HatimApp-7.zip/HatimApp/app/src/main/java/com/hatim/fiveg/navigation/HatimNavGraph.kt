package com.hatim.fiveg.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.hatim.fiveg.data.debug.DebugLogStore
import com.hatim.fiveg.data.repository.RouterRepository
import com.hatim.fiveg.ui.ca.CaAnalyzerScreen
import com.hatim.fiveg.ui.dashboard.DashboardScreen
import com.hatim.fiveg.ui.debug.DebugScreen
import com.hatim.fiveg.ui.diagnostics.DiagnosticsScreen
import com.hatim.fiveg.ui.bandtester.BandTesterScreen
import com.hatim.fiveg.ui.routers.RouterProfilesScreen
import com.hatim.fiveg.ui.settings.SettingsScreen
import com.hatim.fiveg.ui.signal.SignalMonitorScreen

@Composable
fun HatimNavGraph(routerRepository: RouterRepository, debugLogStore: DebugLogStore) {
    // The whole app spec requires full Arabic RTL by default.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val navController = rememberNavController()

        Scaffold(
            bottomBar = {
                NavigationBar {
                    val backStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = backStackEntry?.destination?.route

                    NavDestination.bottomBarItems.forEach { destination ->
                        NavigationBarItem(
                            selected = currentRoute == destination.route,
                            onClick = {
                                navController.navigate(destination.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Text(destination.icon) },
                            label = { Text(destination.labelAr) }
                        )
                    }
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = NavDestination.Dashboard.route,
                modifier = Modifier.padding(innerPadding)
            ) {
                composable(NavDestination.Dashboard.route) {
                    DashboardScreen(routerRepository = routerRepository)
                }
                composable(NavDestination.CaAnalyzer.route) {
                    CaAnalyzerScreen(routerRepository = routerRepository)
                }
                composable(NavDestination.SignalMonitor.route) {
                    SignalMonitorScreen(routerRepository = routerRepository)
                }
                composable(NavDestination.BandTester.route) {
                    BandTesterScreen(routerRepository = routerRepository)
                }
                composable(NavDestination.Routers.route) {
                    RouterProfilesScreen(routerRepository = routerRepository)
                }
                composable(NavDestination.Diagnostics.route) {
                    DiagnosticsScreen(routerRepository = routerRepository)
                }
                composable(NavDestination.Settings.route) {
                    SettingsScreen(
                        routerRepository = routerRepository,
                        onOpenDebug = { navController.navigate("debug") }
                    )
                }
                composable("debug") {
                    DebugScreen(
                        debugLogStore = debugLogStore,
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
