package com.hatim.fiveg.ui.routers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hatim.fiveg.data.local.db.entity.RouterProfileEntity
import com.hatim.fiveg.data.repository.RouterRepository
import com.hatim.fiveg.domain.router.Manufacturer
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RouterProfilesViewModel(
    private val routerRepository: RouterRepository
) : ViewModel() {

    val profiles: StateFlow<List<RouterProfileEntity>> =
        routerRepository.observeProfiles().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * [existing] is the profile being edited, or null when adding a new one.
     * Passing the whole entity (not just its id) matters: it's how isDefault
     * survives an edit — building a fresh RouterProfileEntity from scratch
     * would silently reset isDefault to false on every edit, un-defaulting
     * whatever profile the user had picked.
     */
    fun addOrUpdateProfile(
        existing: RouterProfileEntity?,
        displayName: String,
        manufacturer: Manufacturer,
        routerIp: String,
        username: String,
        password: String
    ) {
        viewModelScope.launch {
            val profile = RouterProfileEntity(
                id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                displayName = displayName,
                manufacturerKey = manufacturer.key,
                routerIp = routerIp,
                isDefault = existing?.isDefault ?: false
            )
            routerRepository.saveProfile(profile, username, password)
        }
    }

    /** The credentials actually stored for a profile, to pre-fill the edit dialog. */
    fun currentCredentials(profileId: String): Pair<String, String> =
        routerRepository.currentCredentials(profileId)

    fun deleteProfile(profile: RouterProfileEntity) {
        viewModelScope.launch { routerRepository.deleteProfile(profile) }
    }

    fun setDefault(profile: RouterProfileEntity) {
        viewModelScope.launch { routerRepository.setDefaultProfile(profile.id) }
    }
}
