package com.hatim.fiveg.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hatim.fiveg.domain.SignalQuality
import com.hatim.fiveg.domain.SignalQualityConfig
import com.hatim.fiveg.ui.theme.StatusExcellent
import com.hatim.fiveg.ui.theme.StatusFair
import com.hatim.fiveg.ui.theme.StatusGood
import com.hatim.fiveg.ui.theme.StatusPoor
import com.hatim.fiveg.ui.theme.StatusUnknown

fun statusColor(quality: SignalQuality): Color = when (quality) {
    SignalQuality.EXCELLENT -> StatusExcellent
    SignalQuality.GOOD -> StatusGood
    SignalQuality.FAIR -> StatusFair
    SignalQuality.POOR -> StatusPoor
    SignalQuality.UNKNOWN -> StatusUnknown
}

/**
 * Big technician-style metric card: value + unit + quality label.
 * [value] null renders "غير متوفر" per the "never invent data" rule.
 */
@Composable
fun MetricCard(
    title: String,
    value: Int?,
    unit: String,
    quality: SignalQuality,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.elevatedCardColors()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = value?.toString() ?: "—",
                    fontSize = 30.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(Modifier.width(4.dp))
                Text(unit, style = MaterialTheme.typography.bodyLarge)
            }
            Spacer(Modifier.height(8.dp))
            AssistChip(
                onClick = {},
                enabled = false,
                label = { Text(SignalQualityConfig.labelAr(quality)) },
                colors = AssistChipDefaults.assistChipColors(
                    disabledContainerColor = statusColor(quality).copy(alpha = 0.18f),
                    disabledLabelColor = statusColor(quality)
                )
            )
        }
    }
}
