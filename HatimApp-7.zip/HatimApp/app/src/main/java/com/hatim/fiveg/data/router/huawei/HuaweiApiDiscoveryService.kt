package com.hatim.fiveg.data.router.huawei

import com.hatim.fiveg.data.debug.DebugLogStore
import com.hatim.fiveg.domain.debug.DebugOutcome
import com.hatim.fiveg.domain.router.AdapterFailureReason
import com.hatim.fiveg.domain.router.AdapterResult
import com.hatim.fiveg.domain.router.RouterConnectionConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

/**
 * Tries each SIGNAL-category candidate from [HuaweiEndpointCatalog] against
 * the connected router, in order, until one responds with something
 * [HuaweiSignalXmlParser] can actually parse. Every attempt — success or
 * failure — is written to [debugLogStore] so the in-app Debug screen can
 * show exactly what was tried.
 *
 * This is discovery, not invention: a candidate is only ever treated as
 * "the" working endpoint after a real HTTP 200 + a real parseable body is
 * observed on the connected device. Nothing is assumed up front.
 */
class HuaweiApiDiscoveryService(
    private val httpClient: OkHttpClient,
    private val debugLogStore: DebugLogStore
) {

    /** Result of a successful discovery: which path worked, and its parsed data. */
    data class DiscoveredSignal(val endpointPath: String, val raw: HuaweiRawSignal)

    suspend fun discoverSignalEndpoint(config: RouterConnectionConfig): AdapterResult<DiscoveredSignal> =
        withContext(Dispatchers.IO) {
            val candidates = HuaweiEndpointCatalog.candidatesFor(HuaweiEndpointCatalog.Category.SIGNAL)

            for (candidate in candidates) {
                val outcome = probe(config, candidate.path)
                if (outcome is ProbeOutcome.Parsed) {
                    return@withContext AdapterResult.Success(
                        DiscoveredSignal(candidate.path, outcome.raw)
                    )
                }
            }

            AdapterResult.Failure(
                AdapterFailureReason.UNSUPPORTED_MODEL,
                "لم يُعثر على Endpoint معروف يوفر بيانات الإشارة على هذا الجهاز/الفيرموير"
            )
        }

    /** Re-checks one already-known-good path without re-running full discovery. */
    suspend fun fetchKnownSignalEndpoint(
        config: RouterConnectionConfig,
        endpointPath: String
    ): AdapterResult<HuaweiRawSignal> = withContext(Dispatchers.IO) {
        when (val outcome = probe(config, endpointPath)) {
            is ProbeOutcome.Parsed -> AdapterResult.Success(outcome.raw)
            is ProbeOutcome.Failed -> AdapterResult.Failure(outcome.reason, outcome.message)
        }
    }

    private sealed class ProbeOutcome {
        data class Parsed(val raw: HuaweiRawSignal) : ProbeOutcome()
        data class Failed(val reason: AdapterFailureReason, val message: String?) : ProbeOutcome()
    }

    private fun probe(config: RouterConnectionConfig, path: String): ProbeOutcome {
        val url = "http://${config.routerIp}/$path"
        val startedAt = System.nanoTime()

        return try {
            val request = Request.Builder().url(url).build()
            httpClient.newCall(request).execute().use { response ->
                val elapsedMs = (System.nanoTime() - startedAt) / 1_000_000

                if (!response.isSuccessful) {
                    debugLogStore.log(
                        manufacturerKey = "huawei",
                        endpointPath = path,
                        httpStatus = response.code,
                        responseTimeMs = elapsedMs,
                        outcome = DebugOutcome.HTTP_ERROR
                    )
                    return ProbeOutcome.Failed(AdapterFailureReason.UNREACHABLE, "HTTP ${response.code}")
                }

                val body = response.body?.string()
                val raw = body?.let { HuaweiSignalXmlParser.parse(it) }

                if (raw == null) {
                    debugLogStore.log(
                        manufacturerKey = "huawei",
                        endpointPath = path,
                        httpStatus = response.code,
                        responseTimeMs = elapsedMs,
                        outcome = DebugOutcome.UNRECOGNIZED_FORMAT
                    )
                    return ProbeOutcome.Failed(AdapterFailureReason.PARSE_ERROR, "استجابة غير معروفة الشكل")
                }

                debugLogStore.log(
                    manufacturerKey = "huawei",
                    endpointPath = path,
                    httpStatus = response.code,
                    responseTimeMs = elapsedMs,
                    outcome = DebugOutcome.SUCCESS
                )
                ProbeOutcome.Parsed(raw)
            }
        } catch (t: Throwable) {
            val elapsedMs = (System.nanoTime() - startedAt) / 1_000_000
            debugLogStore.log(
                manufacturerKey = "huawei",
                endpointPath = path,
                httpStatus = null,
                responseTimeMs = elapsedMs,
                outcome = DebugOutcome.TIMEOUT,
                note = t.javaClass.simpleName
            )
            ProbeOutcome.Failed(AdapterFailureReason.TIMEOUT, t.message)
        }
    }
}
