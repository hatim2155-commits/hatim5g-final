package com.hatim.fiveg.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "speed_tests")
data class SpeedTestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: String,
    val timestampMillis: Long,
    val pingMs: Int?,
    val jitterMs: Int?,
    val downloadMbps: Double?,
    val uploadMbps: Double?
)
