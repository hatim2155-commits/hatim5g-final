package com.hatim.fiveg.data.router.huawei

import com.hatim.fiveg.domain.router.model.*

/**
 * Converts [HuaweiRawSignal] (straight from api/device/signal) into the
 * app's manufacturer-neutral domain models. Any field the router didn't
 * report stays Metric.Unknown — nothing here is guessed.
 */
object HuaweiSignalMapper {

    private fun <T> metricOf(value: T?): Metric<T> =
        if (value != null) Metric.Value(value) else Metric.Unknown

    fun toSignalInfo(raw: HuaweiRawSignal): SignalInfo = SignalInfo(
        rsrp = metricOf(HuaweiSignalXmlParser.stripDbm(raw.rsrp)),
        rsrq = metricOf(HuaweiSignalXmlParser.stripDb(raw.rsrq)),
        sinr = metricOf(HuaweiSignalXmlParser.stripDb(raw.sinr)),
        rssi = metricOf(HuaweiSignalXmlParser.stripDbm(raw.rssi)),
        cqi = metricOf(raw.cqi0?.toIntOrNull())
    )

    fun toLteInfo(raw: HuaweiRawSignal): LteInfo {
        val (dlEarfcn, ulEarfcn) = HuaweiSignalXmlParser.parseDlUlEarfcn(raw.earfcn)
        val components = HuaweiSignalXmlParser.parseBandCombination(raw.band)
        val lteComponent = components.firstOrNull { it.bandLabel.startsWith("B", ignoreCase = true) }

        return LteInfo(
            band = metricOf(raw.bandInfo ?: lteComponent?.bandLabel),
            pci = metricOf(raw.pci?.toIntOrNull()),
            earfcn = metricOf(dlEarfcn), // router doesn't expose a single combined EARFCN; DL used as primary
            dlEarfcn = metricOf(dlEarfcn),
            ulEarfcn = metricOf(ulEarfcn),
            bandwidthMhz = metricOf(
                HuaweiSignalXmlParser.stripMhz(raw.dlBandwidth) ?: lteComponent?.bandwidthMhz
            ),
            rsrp = metricOf(HuaweiSignalXmlParser.stripDbm(raw.rsrp)),
            rsrq = metricOf(HuaweiSignalXmlParser.stripDb(raw.rsrq)),
            sinr = metricOf(HuaweiSignalXmlParser.stripDb(raw.sinr)),
            rssi = metricOf(HuaweiSignalXmlParser.stripDbm(raw.rssi)),
            cqi = metricOf(raw.cqi0?.toIntOrNull()),
            cellId = metricOf(raw.cellId),
            enbId = metricOf(raw.enodebId),
            // Only one LTE component in this reading -> no LTE CA active.
            // A real "3CA" label requires the router to actually report >1
            // LTE component; we never assume aggregation that isn't present.
            carrierAggregation = metricOf(
                components.count { it.bandLabel.startsWith("B", ignoreCase = true) }
                    .takeIf { it > 0 }
                    ?.let { if (it > 1) "${it}CA" else "No CA" }
            )
        )
    }

    fun toNrInfo(raw: HuaweiRawSignal): NrInfo {
        val components = HuaweiSignalXmlParser.parseBandCombination(raw.band)
        val nrComponent = components.firstOrNull { it.bandLabel.startsWith("N", ignoreCase = true) }
        val hasNr = nrComponent != null || raw.nrRsrp != null

        return NrInfo(
            band = metricOf(nrComponent?.bandLabel),
            pci = metricOf(raw.sccPci?.toIntOrNull()),
            nrarfcn = metricOf(raw.nrEarfcn?.toIntOrNull() ?: nrComponent?.arfcn),
            bandwidthMhz = metricOf(
                HuaweiSignalXmlParser.stripMhz(raw.nrDlBandwidth) ?: nrComponent?.bandwidthMhz
            ),
            rsrp = metricOf(HuaweiSignalXmlParser.stripDbm(raw.nrRsrp)),
            rsrq = metricOf(HuaweiSignalXmlParser.stripDb(raw.nrRsrq)),
            sinr = metricOf(HuaweiSignalXmlParser.stripDb(raw.nrSinr)),
            ssb = Metric.Unknown, // not present in this endpoint's response
            cellId = Metric.Unknown, // router doesn't report a separate NR cell id here
            mode = if (hasNr) NetworkType.NR_NSA else NetworkType.LTE, // EN-DC assumed when both LTE+NR present
            carrierAggregation = metricOf(
                components.count { it.bandLabel.startsWith("N", ignoreCase = true) }
                    .takeIf { it > 0 }
                    ?.let { if (it > 1) "${it}CC" else "1CC" }
            ),
            enDc = metricOf(hasNr)
        )
    }

    fun toCaInfo(raw: HuaweiRawSignal): CaInfo {
        val components = HuaweiSignalXmlParser.parseBandCombination(raw.band)
        val lteComponents = components.filter { it.bandLabel.startsWith("B", ignoreCase = true) }
        val nrComponents = components.filter { it.bandLabel.startsWith("N", ignoreCase = true) }

        val lteCarrierComponents = lteComponents.mapIndexed { index, c ->
            CarrierComponent(band = c.bandLabel, bandwidthMhz = c.bandwidthMhz ?: 0.0, isPrimary = index == 0)
        }
        val nrCarrierComponents = nrComponents.mapIndexed { index, c ->
            CarrierComponent(band = c.bandLabel, bandwidthMhz = c.bandwidthMhz ?: 0.0, isPrimary = index == 0)
        }

        val totalLte = lteComponents.mapNotNull { it.bandwidthMhz }.sum().takeIf { lteComponents.isNotEmpty() }
        val totalNr = nrComponents.mapNotNull { it.bandwidthMhz }.sum().takeIf { nrComponents.isNotEmpty() }
        val totalAggregated = listOfNotNull(totalLte, totalNr).sum().takeIf { totalLte != null || totalNr != null }

        return CaInfo(
            lteComponents = lteCarrierComponents,
            nrComponents = nrCarrierComponents,
            lteCaLabel = metricOf(if (lteComponents.isNotEmpty()) "${lteComponents.size}CA" else null),
            nrCaLabel = metricOf(if (nrComponents.isNotEmpty()) "${nrComponents.size}CC" else null),
            totalLteBandwidthMhz = metricOf(totalLte),
            totalNrBandwidthMhz = metricOf(totalNr),
            totalAggregatedBandwidthMhz = metricOf(totalAggregated)
        )
    }

    fun toCellInfo(raw: HuaweiRawSignal): CellInfo = CellInfo(
        cellId = metricOf(raw.cellId),
        pci = metricOf(raw.pci?.toIntOrNull()),
        trackingAreaCode = metricOf(raw.tac)
    )
}
