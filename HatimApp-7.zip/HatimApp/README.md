# HATIM 5G

أداة Android لمراقبة وإدارة راوترات 4G/5G عبر شبكة Wi-Fi المحلية، مبنية على
طبقة تجريد (Router Abstraction Layer) قابلة للتوسع لدعم عدة شركات مصنعة.

> **حالة المشروع:** البنية، الواجهات، الشاشات، وقاعدة البيانات جاهزة.
> `HuaweiAdapter` الآن يستخدم **طبقة Router API Discovery** حقيقية بدل
> افتراض Endpoint ثابت لكل أجهزة هواوي:
> - عند أول قراءة، يجرّب `HuaweiApiDiscoveryService` المرشّحين المعروفين في
>   `HuaweiEndpointCatalog` بالترتيب، ويتوقف عند أول Endpoint يرجع بيانات
>   قابلة للتحليل فعليًا.
> - `api/device/signal` مؤكد على **Huawei H155-383** (جهازك) ومُدرج أولًا،
>   لذا يُستخدم مباشرة على هذا الجهاز دون تجربة البقية.
> - أي موديل/فيرموير هواوي آخر يمر بنفس عملية الاكتشاف تلقائيًا؛ إن لم
>   يستجب أي مرشّح، يُعاد `UNSUPPORTED_MODEL` بدل اختلاق بيانات.
> - النتيجة (Endpoint الناجح) تُخزَّن في الذاكرة لكل IP راوتر، فلا يُعاد
>   الاكتشاف الكامل مع كل قراءة.
> - **وضع Debug** (Settings ← "وضع Debug") يعرض كل محاولة: اسم الـEndpoint،
>   HTTP status، زمن الاستجابة، والنتيجة — بدون أي بيانات دخول أو محتوى حساس
>   (`DebugLogStore` في الذاكرة فقط، لا يُخزَّن على القرص ولا يُرسل لأي مكان).
>
> باقي الدوال (`RouterInfo`, `NetworkStatus`, `FirmwareInfo`, تسجيل دخول
> حقيقي بجلسة/توكن) لا تزال `UNSUPPORTED_MODEL` حتى تُضاف مرشّحاتها الخاصة
> إلى `HuaweiEndpointCatalog` وتُؤكَّد باستجابة حقيقية. `ZteAdapter` و
> TP-Link لا يزالان بانتظار دورهما بعد استقرار Huawei، كما طلبت.

## 1. أين تضع الملفات

هذا مشروع Android Studio كامل. فك الضغط عن `HatimApp.zip` بأي مكان، ثم:

```
File → Open → اختر مجلد HatimApp
```

سيتعرف Android Studio على المشروع تلقائيًا عبر `settings.gradle.kts`.
لا تحتاج لنقل أي ملف يدويًا — البنية جاهزة:

```
HatimApp/
├── app/
│   ├── build.gradle.kts        ← تبعيات الموديول
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/hatim/fiveg/
│       │   ├── HatimApplication.kt      (حاوية DI يدوية بسيطة)
│       │   ├── MainActivity.kt
│       │   ├── navigation/              (Bottom nav + NavHost, RTL)
│       │   ├── ui/                      (كل شاشة في حزمتها الخاصة)
│       │   ├── domain/router/           (RouterAdapter + النماذج + Manufacturer)
│       │   ├── data/router/             (Factory + Huawei/ZTE Adapters)
│       │   ├── data/security/           (SecureCredentialsStore)
│       │   └── data/local/db/           (Room: profiles/signal logs/tests)
│       └── res/
└── build.gradle.kts / settings.gradle.kts / gradle.properties
```

## 2. كيف تشغّل المشروع

المتطلبات:
- Android Studio (Koala أو أحدث يفضّل)
- JDK 17 (يأتي مدمجًا مع Android Studio عادة)
- SDK 34 مثبت عبر SDK Manager

الخطوات:
1. افتح المشروع في Android Studio (كما بالأعلى).
2. انتظر Gradle Sync (أول مرة قد تستغرق بضع دقائق لتحميل التبعيات).
3. اختر جهازًا حقيقيًا أو محاكي (يفضّل جهاز حقيقي متصل بشبكة الراوتر Wi-Fi
   فعليًا، لأن التطبيق يعمل Local Network First).
4. اضغط Run ▶.

## 3. كيف تبني APK

من Android Studio:
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
الملف الناتج يكون تحت:
```
app/build/outputs/apk/debug/app-debug.apk
```

من سطر الأوامر (بعد فتح المشروع مرة واحدة في Android Studio ليُنشئ
`gradlew`/`gradlew.bat`، أو بتثبيت Gradle محليًا):
```
./gradlew assembleDebug
```

> ملاحظة: لم يتم تضمين `gradle/wrapper/gradle-wrapper.jar` في هذه الحزمة
> الأولية لتقليل الحجم. افتح المشروع مرة في Android Studio وسيقوم بإنشاء/
> تنزيل الـ wrapper تلقائيًا، أو نفّذ `gradle wrapper` إذا كان لديك Gradle

## 3.5. بناء APK تلقائيًا عبر GitHub Actions (بدون Android Studio)

المشروع فيه ملف جاهز: `.github/workflows/build-debug-apk.yml`.

الخطوات:
1. أنشئ مستودعًا (Repository) جديدًا فارغًا على GitHub (عام أو خاص، الاثنان يدعمان Actions مجانًا للحسابات الشخصية ضمن حد شهري).
2. ارفع محتوى مجلد `HatimApp` كاملاً إلى المستودع (عبر GitHub Desktop، أو من سطر الأوامر: `git init && git add . && git commit -m "init" && git branch -M main && git remote add origin <رابط_مستودعك> && git push -u origin main`).
3. بمجرد الرفع، يبدأ الـ Workflow تلقائيًا (تقدر تتابعه من تبويب **Actions** بالمستودع). يأخذ عادة بضع دقائق.
4. بعد اكتمال التشغيل بنجاح (✅ خضراء)، افتح التشغيل من تبويب Actions → بالأسفل قسم **Artifacts** → حمّل `HatimApp-debug-apk` (ملف zip يحتوي `app-debug.apk`).
5. فك الضغط، انقل `app-debug.apk` لهاتفك، وثبّته.

> ملاحظة: هذا الـ Workflow يستخدم Gradle مباشرة (`gradle assembleDebug`)
> بدل `./gradlew`، لأن `gradle-wrapper.jar` غير مرفق كما هو موضح أعلاه —
> GitHub Actions يثبّت Gradle بنفسه عبر `gradle/actions/setup-gradle`،
> فلا تحتاج تضيف الـ wrapper يدويًا ليعمل البناء هناك.
> مثبت.

## 4. كيف تضيف Endpoint جديد لطبقة الاكتشاف (Huawei)

1. افتح `data/router/huawei/HuaweiEndpointCatalog.kt`.
2. أضف مرشّحًا جديدًا لقائمة `candidates`، مثال:
   ```kotlin
   Candidate("api/device/information", Category.DEVICE_INFO, "غير مؤكد بعد")
   ```
3. لا حاجة لتعديل `HuaweiApiDiscoveryService` — إن كانت الفئة `SIGNAL`
   سيُجرَّب المرشّح تلقائيًا ضمن `discoverSignalEndpoint()`.
4. لفئات جديدة كليًا (مثل `DEVICE_INFO` الفعلية بدل بقائها غير مستخدمة)،
   أضف دالة اكتشاف مشابهة لـ`discoverSignalEndpoint()` في
   `HuaweiApiDiscoveryService.kt`، ثم مِرسال نتيجتها إلى Mapper مخصص (على
   غرار `HuaweiSignalMapper.kt`) بمجرد أن ترسل لي عيّنة XML حقيقية لذلك
   الـEndpoint.
5. تحقق من النتيجة عمليًا عبر **وضع Debug** داخل التطبيق (Settings ← وضع
   Debug) — سترى فورًا أي Endpoint نجح، برمز الحالة HTTP وزمن الاستجابة.

## 5. كيف تضيف دعم API جديد لـ ZTE / TP-Link

نفس الخطوات أعلاه لكن في `data/router/zte/ZteAdapter.kt`. لاحظ أن أجهزة ZTE
المختلفة (MF9x مقابل MC888 مثلاً) غالبًا لا تتشارك نفس شكل الـ API، لذلك
الأفضل غالبًا إنشاء كلاس Adapter منفصل لكل عائلة موديلات (مثال:
`ZteMc888Adapter`) بدل توسيع كلاس واحد بحالات متعددة غير موثقة.

## 6. إضافة شركة مصنعة جديدة بالكامل (TP-Link, Nokia, Zyxel, D-Link, ...)

1. أضف كلاس جديد في `data/router/<company>/<Company>Adapter.kt` يطبّق
   واجهة `RouterAdapter`.
2. أضف حالة جديدة في `RouterAdapterFactory.create(...)` تربط
   `Manufacturer.XXX` بالكلاس الجديد.
3. لا حاجة لتعديل أي شاشة UI أو ViewModel — الجميع يتعامل مع
   `RouterAdapter` كواجهة موحّدة فقط.

## 7. الأمان (ملخص — التفاصيل في SECURITY.md)

- بيانات الدخول (Username/Password) تُخزَّن محليًا فقط عبر
  `EncryptedSharedPreferences` المرتبط بـ Android Keystore.
- لا يتم إرسال كلمة المرور أو IMEI أو أي بيانات راوتر إلى أي خادم خارجي.
- التطبيق "Local Network First": لا حاجة لإنترنت لعرض بيانات الراوتر، فقط
  للـ Speed Test أو فحص تحديثات الفيرموير.

## 8. الخطوات التالية المقترحة

- تنفيذ HuaweiSession الحقيقي (login handshake) بعد تزويدي بتفاصيل جهاز حقيقي.
- ربط Signal Monitor بالتسجيل الفعلي في Room + رسوم Vico التفاعلية.
- شاشة Router Info الكاملة (مع إخفاء IMEI بالنمط `************1234`).
- Export Report (CSV ثم PDF).
- Band Lock UI (تُفعَّل فقط عندما `supportsBandLock()` تُرجع true).
